-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.7.19 - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para algorath_db
CREATE DATABASE IF NOT EXISTS `algorath_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `algorath_db`;

-- Volcando estructura para tabla algorath_db.relations
CREATE TABLE IF NOT EXISTS `relations` (
  `user1_id` int(10) unsigned NOT NULL,
  `user2_id` int(10) unsigned NOT NULL,
  KEY `relations_user1_id_foreign` (`user1_id`),
  KEY `relations_user2_id_foreign` (`user2_id`),
  CONSTRAINT `relations_user1_id_foreign` FOREIGN KEY (`user1_id`) REFERENCES `users` (`id`),
  CONSTRAINT `relations_user2_id_foreign` FOREIGN KEY (`user2_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla algorath_db.relations: ~16 rows (aproximadamente)
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
INSERT INTO `relations` (`user1_id`, `user2_id`) VALUES
	(1, 1),
	(1, 2),
	(3, 4),
	(3, 1),
	(4, 1),
	(5, 1),
	(5, 2),
	(5, 3),
	(4, 1),
	(3, 1),
	(1, 2),
	(1, 2),
	(1, 4),
	(3, 3),
	(1, 2),
	(1, 3),
	(1, 2);
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;

-- Volcando estructura para tabla algorath_db.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla algorath_db.users: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `created_at`, `updated_at`) VALUES
	(1, 'user1', '2018-10-21 14:48:36', '2018-10-21 14:48:36'),
	(2, 'user2', '2018-10-21 15:09:34', '2018-10-21 15:09:34'),
	(3, 'user3', '2018-10-21 15:10:20', '2018-10-21 15:10:20'),
	(4, 'user4', '2018-10-21 15:10:27', '2018-10-21 15:10:27'),
	(5, 'Relacionado', '2018-10-21 15:31:56', '2018-10-21 15:31:56');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
